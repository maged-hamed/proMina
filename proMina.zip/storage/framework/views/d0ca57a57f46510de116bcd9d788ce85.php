<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            Show: <?php echo e($album->name); ?>

        </div>

        <div class="card-body">
            <div class="form-group">

                <table class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th>
                            Image
                        </th>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $album->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <td>
                                <div class="row">
                                   <a href="<?php echo e($image->url); ?>" target="_blank"> <img style="width: 100px; height: 100px;"
                                         src="<?php echo e($image->url); ?>">
                                   </a>
                                    
                                </div>
                            </td>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="form-group">
                    <a class="btn btn-default" href="<?php echo e(route('admin.album.index')); ?>">
                        Back
                    </a>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/uni-ecommerce/resources/views/admin/album/show.blade.php ENDPATH**/ ?>