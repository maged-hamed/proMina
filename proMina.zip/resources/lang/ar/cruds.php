<?php

return [
    'products' => [
        'title' => 'المنتجات',
        'title_singular' => 'المنتجات',
        'fields' => [
            'id' => 'الرقم التسلسلي',
            'name' => 'الاسم',
            'image' => 'الصورة',
            'price' => 'السعر',
            'quantity' => 'الكمية',
        ],
    ],

];
