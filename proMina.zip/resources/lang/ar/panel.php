<?php

return [
    'site_title' => 'ISO',
];
