<?php

return [
    'products' => [
        'title' => 'products',
        'title_singular' => 'products',
        'fields' => [
            'id' => 'ID',
            'name' => 'Name',
            'image' => 'Image',
            'price' => 'Price',
            'quantity' => 'Quantity',
        ],
    ],

];
